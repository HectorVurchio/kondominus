venezuela-sql
=============

Base de datos de la división político territorial de Venezuela. Se incluyen estados, ciudades, municipios y parroquias de Venezuela en formato .sql.

La lista de estados tiene su código ISO 3166-2 correspondiente.


Referencias
-----------

1. Instituto Nacional de Estadística de Venezuela: http://www.ine.gov.ve/
2. Wikipedia http://es.wikipedia.org/

###Contacto

Para colaborar o hacer correcciones, puedes contactarme:

Web: http://marydenobrega.com/
E-mail: denobrega.mary@gmail.com
Twitter: @Marydn